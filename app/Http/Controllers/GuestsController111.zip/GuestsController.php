<?php

namespace App\Http\Controllers;

use App\Branch;
use App\Guest;
use App\Table;
use App\GuestRoute;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;



class GuestsController extends Controller
{
    public function index()
    {
        $items = Guest::all();
        return $items;
    }

    public function getAll()
    {
        $branches = Branch::all();
        $items = Guest::where("is_inside", '<', 999)->with('routes.branch')->get();
        $items->branches = $branches;
        Storage::disk('local')->put('all.json', $items);
        return view('registration.index')->with(['branches' => $branches, 'file' => 'all.json']);
    }
    public function getRegistration()
    {
        $items = Guest::where("is_inside", 0)->with('routes.branch')->get();
        $branches = Branch::all();
        $items->branches = $branches;
        Storage::disk('local')->put('registration.json', $items);
        return view('registration.index')->with(['branches' => $branches, 'file' => 'registration.json']);
    }
    public function getDistribution($id, $table)
    {
        $branches = Branch::all();
        $items = \DB::select('
            SELECT *
            FROM guests g
            LEFT JOIN guests_routes gr ON(
                g.id = gr.guest_id
                AND NOT EXISTS (
                    SELECT 1 FROM guests_routes i
                    WHERE i.guest_id = g.id
                    AND i.id > gr.id
                )
            )
            Where gr.branche_id = '.$id.'
            OR gr.table_id = '.$table.'
        ');
        Storage::disk('local')->put($table.'.json', json_encode($items));
        return view('distribution.index')->with(['branches' => $branches, 'file' => $table.'.json', 'table' => $table, 'branche' => $id]);
    }
    public function registerGuest($id, $branch){
        $guest = Guest::find($id);
        $guest->is_inside = 1;
        $guest->status = 'הגיע';
        $dt = new \DateTime;
        $guest->time_reg = $dt->format('Y-m-d H:i:s');
        $guest->save();

        $guestRoute = new GuestRoute;
        $guestRoute->guest_id = $id;
        $guestRoute->position_id = 1;
        $guestRoute->branche_id = $branch;
        $guestRoute->save();
    }

    public function store(Request $request)
    {
        $item = new Guest;
        $item->name = $request->name;
        $item->phone = $request->phone;
        $item->is_inside = 1;
        $item->status = 'הגיע';
        $dt = new \DateTime;
        $item->time_reg = $dt->format('Y-m-d H:i:s');
        $item->save();

        $guestRoute = new GuestRoute;
        $guestRoute->guest_id = $item->id;
        $guestRoute->position_id = 1;
        $guestRoute->branche_id = $request->branch;
        $guestRoute->save();
        return $item;
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function Call($id, $table)
    {
        $guest = Guest::find($id);
        $guest->status = 1;
    }

}
